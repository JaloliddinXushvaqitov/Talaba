package com.example.talaba.Dto;

import lombok.Data;

@Data
public class FakultetDTO {
    private String fakulNomi;
    private  Integer universitetID;

}
