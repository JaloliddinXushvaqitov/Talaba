package com.example.talaba.Dto;

import lombok.Data;

@Data
public class QorivulDTO {
    private String qorovulism;
    private String qorovulfam;
    private String tel;
    private String viloyat;
    private String tuman;
    private String kucha;
}
