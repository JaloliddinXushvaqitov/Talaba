package com.example.talaba;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TalabaApplication {

    public static void main(String[] args) {
        SpringApplication.run(TalabaApplication.class, args);
    }

}
