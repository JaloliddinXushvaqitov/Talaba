package com.example.talaba.Dto;

import lombok.Data;

@Data

public class UniversitetDTO {
    private  String nomi;
    private  String viloyat, tuman,kocha;
}
