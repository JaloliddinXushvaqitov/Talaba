package com.example.talaba.Dto;

import lombok.Data;

@Data
public class TalabaDto {
    private String ism,fam,telRaqam,viloyat,tuman,kucha;
}
