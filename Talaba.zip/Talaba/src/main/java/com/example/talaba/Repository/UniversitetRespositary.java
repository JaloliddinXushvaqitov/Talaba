package com.example.talaba.Repository;

import com.example.talaba.Entity.Manzil;
import com.example.talaba.Entity.Universitet;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UniversitetRespositary  extends JpaRepository<Universitet,Integer>{

}
